function CF=GetCF(A)
%jingjing write, and to change the A to aormat of cell array
[row,col]=size(A);
CF=cell(1,row);
for i=1:row
    j=1:col;
    CF{1,i}(j)=A(i,j);
end