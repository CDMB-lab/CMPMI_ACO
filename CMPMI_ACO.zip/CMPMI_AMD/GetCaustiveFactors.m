function CaustiveFactors=GetCaustiveFactors(SNPname,matName)
%5.27/2010 by Junliang Shang
%�������ݼ��е�ĳ��SNPname��ʵ�����ҵ������ֱ�ǩ
%%%%%%input
%SNPname ��ʵSNP��
%matName ���ݼ�
%%%%%output
%CaustiveFactors ���ֱ�ǩ
% SNPname{1}(1)=mat2cell('rs380390')
%%
%load
string=[matName,'_Name.mat'];
temp=load(string);
Name=temp.Name;
clear string temp;
%%
%Get CaustiveFactors
for i=1:length(SNPname)
    for j=1:length(SNPname{i})
        for k=1:length(Name)
            if strcmp(cell2mat(Name(1,k)),cell2mat(SNPname{i}(j)))
                break;
            end
        end
        CaustiveFactors{i}(j)=k;
    end
end
clear i j k Name;
for i=1:length(SNPname)
    disp('====================================');
    if ~isempty(SNPname)
        disp([SNPname{i}]);
    end
    disp(['[',num2str(CaustiveFactors{i}),']']);
end
clear SNPname i;