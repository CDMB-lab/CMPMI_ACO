
%% jingjing write, Write cell file to excel file format
name_length=length(SNPname);
SNP_name=[SNPname{:}];
SNP_name=reshape(SNP_name,length(SNP_name)/name_length,name_length);
% SNP_name=cell2table(SNP_name);
writecell(SNP_name,'SNP_20000_1000.xls')