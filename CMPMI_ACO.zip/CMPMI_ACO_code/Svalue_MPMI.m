%% �����޸� ֻ��MPMI��Ϊ��Ⱥ�����2021-9-24
function FitnessValue=Svalue_MPMI(pts,class,factor)
%% fitness function Svalue
snp1=pts(:,factor(1));
snp2=pts(:,factor(2));
FitnessValue=0.5*(MPMI(snp1,class,snp2)+MPMI(snp2,class,snp1));
end
%%
function mpmi=MPMI(x,y,z)
npa=exp(2*MI(z,x))*CMI(x,y,z)*exp(2*MI(z,y)); %NPA
mpmi=D(x,y,z)+npa;
end
%% compute MI
function MI_value=MI(f,c)
% Compute Mutual Information between class label and a SNP set.
% f ����ΪSNP����ֵΪ1 2 3��c���ɣ�ֵ���
f=double(f);
c=double(c);
c=c-min(c(:))+1; 

Num_c=max(c(:));
Num_fType=max(f(:));
[Num_Sample,Num_Feature,]=size(f);

H_c=hist(c,Num_c);
P_c=H_c/Num_Sample;
Entropy_c=-P_c*log2(P_c'+eps);

N_fc=zeros(Num_fType^Num_Feature,Num_c);
for j=1:Num_Sample
    N_fc(f(j),c(j))=N_fc(f(j),c(j))+1; % calculate N(f,c)
end

sumHist=sum(N_fc,2);   %calculate p(f)
repHist=repmat(sumHist,1,Num_c);
pHist_c=N_fc./(repHist+eps);%p(c/f)=p(c,f)/p(f).
InfoIncre=-sum((log2(pHist_c+eps).*pHist_c).*(repHist));
MI_value=Entropy_c-sum(InfoIncre)/Num_Sample;
return;
end

%% compute CMI of x y and labels
function CMI_value = CMI( x,y,z)
%Conditional Mutual Information = sum( P(x,y,z)*log(P(x,y,z)P(z)/(P(x,z)*P(y,z)));
% Input data x, y, z and compute CMI(X,Y|Z)
Num_z=max(z(:));
Num_x=max(x(:));
Num_y=max(y(:));
[Num_Sample,Num_Feature]=size(x);

ZZ=Num_x.^(Num_Feature-1:-1:0)';%���￼��x�Ǹ����ϵ�����ˣ�������Ҳ����
tempIndex=ZZ'*x;
Nxyz=zeros(Num_x^Num_Feature,Num_y,Num_z);%z is labels,y��ԭ��������z
for j=1:Num_Sample
    Nxyz(tempIndex(j),y(j),z(j))=Nxyz(tempIndex(j),y(j),z(j))+1;
end
Pxyz=Nxyz./Num_Sample;
Pxy=sum(Pxyz,3);
Pxz=sum(Pxyz,2);
Pyz=sum(Pxyz,1);
Pz=sum(sum(Pxyz));
Pz_PxzPyz=Pz./Pxz./Pyz;
E=Pxyz.*log2(Pxyz.*Pz_PxzPyz);
E(Pxyz==0)=0;
CMI_value = sum(E(:));
end
%% compute the sum of Kullback-Leibler(KL) divergence D between x labels and y
function I = D( x,y,z)

Num_z=max(z(:));
Num_x=max(x(:));
Num_y=max(y(:));
[Num_Sample,Num_Feature]=size(x);

ZZ=Num_x.^(Num_Feature-1:-1:0)';%���￼��x�Ǹ����ϵ�����ˣ�������Ҳ����
tempIndex=ZZ'*x;
Nxyz=zeros(Num_x^Num_Feature,Num_y,Num_z);%z is labels,y��ԭ��������z
for j=1:Num_Sample
    Nxyz(tempIndex(j),y(j),z(j))=Nxyz(tempIndex(j),y(j),z(j))+1;
end

Pxyz=Nxyz./Num_Sample;
n=size(Pxyz);
Pxz=sum(Pxyz,2);   %P(x,z)
Px=sum(Pxz,3);  %P(x)
Pyz=sum(Pxyz,1);    %P(y,z)
Py=sum(Pyz,3);  %P(y)
Pz=sum(sum(Pxyz));  %P(z)

Px_yz=cell2mat(arrayfun(@(i)Pxyz(i,:,:)./Pyz,[1:n(1)]','UniformOutput',0));
Px_z=cell2mat(arrayfun(@(i)Pxz(:,:,i)./Pz(i),reshape(1:n(3),1,1,[]),'UniformOutput',0));
Px_z=repmat(Px_z,[1 n(2) 1]);
Px_yz(isnan(Px_yz))=0;
Sy_Px_yzPy=sum(cell2mat(arrayfun(@(i)Px_yz(:,i,:).*Py(i),1:n(2),'UniformOutput',0)),2);

%%
Py_xz=cell2mat(arrayfun(@(i)Pxyz(:,i,:)./Pxz,1:n(2),'UniformOutput',0));
Py_z=cell2mat(arrayfun(@(i)Pyz(:,:,i)./Pz(i),reshape(1:n(3),1,1,[]),'UniformOutput',0));
Py_z=repmat(Py_z,[n(1) 1 1]);
Py_xz(isnan(Py_xz))=0;
Sx_Py_xzPx=sum(cell2mat(arrayfun(@(i)Py_xz(i,:,:).*Px(i),[1:n(1)]','UniformOutput',0)),1);


Plog1=Px_z./Sy_Px_yzPy;
E1=Pxyz.*log2(Plog1);
E1(Pxyz==0)=0;
D1=sum(E1(:));


Plog2=Py_z./Sx_Py_xzPx;
E2=Pxyz.*log2(Plog2);
E2(Pxyz==0)=0;
D2=sum(E2(:));

I=D1+D2;
end

