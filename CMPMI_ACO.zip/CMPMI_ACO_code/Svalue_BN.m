
function FitnessValue=Svalue_BN(pts,class,factor,Amplification)
%% fitness function Svalue

FitnessValue=Amplification*(1/BN(pts,class,factor));

end

function FitnessValue=BN(pts,class,factor)
%% The Bayes Network value

snp_com=pts(:,factor)-1;
state=class'-1;
[xrow,~] = size(snp_com);
subs = snp_com+1;
sample = accumarray(subs,ones(xrow,1));
disease = accumarray(subs,state);
control = sample-disease;
sample(4,4) = 0;
disease(4,4) = 0;
control(4,4) = 0;
z=0;
for i = 1:3
    for j = 1:3
        y=My_factorial(sample(i,j)+1);
        r=My_factorial(disease(i,j))+My_factorial(control(i,j));
        z=z+(r-y);
    end
end
FitnessValue=abs(z);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function f=My_factorial(e)
f=0;
if e>0
    for o=1:e
        f=f+log(o);
    end
end
end