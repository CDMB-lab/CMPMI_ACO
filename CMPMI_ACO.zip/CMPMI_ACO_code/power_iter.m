% for iteration
clear
clc

data_size=100;
AntNumber=200;

startIndex=1;
endIndex=100;

tic;
%%
 a=1;
 for IterationNumber=10:30:160
    acc_1 = 0;
    acc_2 = 0;
for dataSetId = startIndex:endIndex   
        %     load(['E:\wangjing\4000—1000\Model8\' strcat('SNP_',num2str(dataSetId)) '.mat'])
        load(['E:\wangjing\4000_100\4000_100\Model5\' strcat('SNP_',num2str(dataSetId)) '.mat'])
        data=[double(pts),class'];
        factor=sort(factor);
%       data=data+1;
%       factor=sort(factor_truth);
        [Result_final,~,~]=epiACO3(data,AntNumber,IterationNumber,0.2);%CMPMI_ACO
        Result=sort(Result_final,2);           
%% calculate power   
NumResult=size(Result,1);
Counter=zeros(endIndex-startIndex+1,3);
if NumResult==0
    Counter(dataSetId,1)=0;
    Counter(dataSetId,2)=0;
    Counter(dataSetId,3)=0;
end
    
if NumResult==1
    Counter(dataSetId,1)=isequal(factor,Result);
    Counter(dataSetId,2)=Counter(dataSetId,1);
    Counter(dataSetId,3)=1;
end

if NumResult>1
    Counter(dataSetId,1)=isequal(factor,Result(1,:));
    if Counter(dataSetId,1)==1
        Counter(dataSetId,2)=1;
    else
        for j=2:NumResult
            if isequal(factor,Result(j,:))==1
                Counter(dataSetId,2)=1;
            end
        end
    end
    Counter(dataSetId,3)=NumResult;
end

if Counter(dataSetId,1) == 1
    acc_1 = acc_1 + 1;
end

if Counter(dataSetId,2) == 1
    acc_2 = acc_2 + 1;
end
end
power1(a) = acc_1/endIndex;
power2(a)= acc_2/endIndex;
a=a+1;
end
time=toc;
save('model5_100_MPMI_iter','power1','power2','time')

