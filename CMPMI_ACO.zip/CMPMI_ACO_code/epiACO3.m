function [Result_final,Value_final,Time]=epiACO3(data,AntNumber,IterationNumber,evaporation)
%% EpiACO main program for the detection of SNP-SNP interactions
% Input
%   Data:            The input data matrix, where the elements are 0 1 2                  
%   AntNumber:       The ant number. for example, AntNumber=50.
%   IterationNumber: The iteration number. for example, IterationNumber=20.
%   evaporation:     The evaporation of Tau. for example,evaporation=0.9.
%
% Output
%   Result_final:   The final results.
%   Value_final:    The Svalues of final results.
%   Time:           The computational time.
%
%% Time Begin
tic;

%% Unimportant Parameters
% The considered order of SNP-SNP interactions.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ratio
ratio=0.5;
Dimension=2;

% The initialized Tau value.
Tau0=1;

% The coefficient of Tau.
Alfa=1;

% The initialized Eta value.
Eta0=1;

% The coefficient of Eta.
Beta=1;

% The amplification of Svalue.
Amplification=10000;

%% Input data
[~,column]=size(data);
pts=data(:,1:column-1);
class=(data(:,column))';
SNPNumber=size(pts,2);

%% Initialize Parameters
% Initialize Tau
Tau=Tau0*ones(1,SNPNumber);

% Initialize Eta
Eta=Eta0*ones(1,SNPNumber);

% Initialize Combination
 Combination=zeros(AntNumber,Dimension);
 Combination1=[];
 FitnessValue1=[];
 
% Initialize FitnessValue
FitnessValue=zeros(AntNumber,1);

% initialize Value
Value=zeros(AntNumber,1);

% initialize Result
Result=zeros(AntNumber,Dimension);
Tag=1;
%% Iteration

disp('Waitting...');

for i=1:IterationNumber
    %%
    % Select combinations and evaluate them.
    q0=i/IterationNumber;
    for j=1:AntNumber
        Combination(j,:)=SelectCombination(Tau,Eta,Alfa,Beta,q0,Dimension,ratio);
        FitnessValue(j,1)=Svalue_MPMI(pts,class,Combination(j,:));     
    end  
    %%  
    for k=1:size(FitnessValue,1)
       if FitnessValue(k)>Value(Tag)
           Combination2=Combination(k,:);
           FitnessValue2=FitnessValue(k,:);
           Combination1=[Combination1;Combination2];
           FitnessValue1=[FitnessValue1;FitnessValue2];
        end 
     end 
    %%     
    TempCombination=[Combination1;Result];
    TempFitnessValue=[ FitnessValue1;Value];
    
    [TempCombination,RowIndex,~]=unique(TempCombination,'rows');
    TempFitnessValue=TempFitnessValue(RowIndex,:);
    
    [TempFitnessValue,Index]=sort(TempFitnessValue,'descend');
    TempCombination=TempCombination(Index,:);
    
    Tag=InflexionPoint(TempFitnessValue);
    Result=TempCombination(1:Tag,:);
    Value=TempFitnessValue(1:Tag,:);
    
    %%  Update pheromone
   Tau=UpdatePheromone(Tau,Combination,FitnessValue,evaporation);
    if sum(Tau>mean(Tau))<=max(2,floor(SNPNumber*0.1))
        break;
    end  
end
% post processing
[Tau,Index]=sort(Tau,'descend');
Lab=InflexionPoint(Tau');
Lab=min([Lab,sum(Tau>mean(Tau)),50]);

matrix=Index(1,1:Lab);
TempCombination1=nchoosek(matrix,Dimension);
TempCombination1=sort(TempCombination1,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%
TempCombination1=setdiff(TempCombination1,Result,'rows');
%%%%%%%%%%%%%%%%%%%%%%%%%%%
r=size(TempCombination1,1);
TempFitnessValue1=zeros(r,1);

for i=1:r
    TempFitnessValue1(i,1)=Svalue_MPMI(pts,class,TempCombination1(i,:));
end

 TempCombination2=[Result;TempCombination1];
 TempFitnessValue2=zeros(size(TempCombination2,1),1);
for k=1:size(TempCombination2,1)
    TempFitnessValue2(k,1)=Svalue_BN(pts,class,TempCombination2(k,:),Amplification);
end
  [TempFitnessValue_final,Index]=sort(TempFitnessValue2,'descend');
  TempCombination_final=TempCombination2(Index,:);
  final_number=size(TempFitnessValue_final,1);
  if final_number<20
      Value_final=TempFitnessValue_final(1:final_number,:);
      Result_final=TempCombination_final(1:final_number,:);
  else
      Value_final=TempFitnessValue_final(1:20,:);
      Result_final=TempCombination_final(1:20,:);
  end

%% Time End
Time=toc;
save('result_2000_2000_300','Result_final','Value_final','Time')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Combination=SelectCombination(Tau,Eta,Alfa,Beta,q0,Dimension,ratio)
%% Select a SNP combination according to the probability formula
[~,index]=sort(Tau);
index1=index(1,1:floor(ratio*size(index,2)));
Number=size(index1,2);
Combination=zeros(1,Dimension);
if rand>q0
    combine=randperm(Number,Dimension);
    Combination=index(combine);
else
    for i=1:Dimension
        Weight=(Alfa*Tau).*(Beta*Eta);
        SumWeight=sum(Weight);
        Ratio=Weight/SumWeight;
        Combination(1,i)=Roulette(Ratio);
        Tau(1,Combination(1,i))=0;
    end
end
Combination=sort(Combination);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function SNP=Roulette(Ratio)
%% A roulette

Sel=rand;
SumPs=0;
i=1;
while SumPs<Sel
    SumPs=SumPs+Ratio(1,i);
    i=i+1;
end
SNP=i-1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Tag=InflexionPoint(TempFitnessValue)
%% Find a inflexion point
PointNumber=size(TempFitnessValue,1);

Slope=zeros(1,PointNumber-1);
Slope2=zeros(1,PointNumber-2);

for i=1:(PointNumber-1)
    Slope(1,i)=TempFitnessValue(i,1)-TempFitnessValue(i+1,1);
end

for i=1:(PointNumber-2)
    Slope2(1,i)=abs(Slope(1,i)-Slope(1,i+1));
end

[~,Tag]=max(Slope2);
Tag=Tag+2;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Tau=UpdatePheromone(Tau,Combination,FitnessValue,evaporation)
%% Update pheromone
DeltaTau=zeros(1,size(Tau,2));
for i=1:size(Combination,1)
    DeltaTau(1,Combination(i,:))=DeltaTau(1,Combination(i,:))+FitnessValue(i,1);
end
Tau=Tau.*(1-evaporation)+DeltaTau;
end

