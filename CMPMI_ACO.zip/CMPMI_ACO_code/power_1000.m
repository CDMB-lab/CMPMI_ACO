%calculate in 1000-SNP
clear
clc
IterationNumber =100;
data_size=50;

AntNumber=2000;
startIndex=1;
endIndex=50;

tp_all=zeros(data_size,1);
fn_all=zeros(data_size,1);
fp_all=zeros(data_size,1);
tn_all=zeros(data_size,1);
tic;
%% 
    acc_1 = 0;
    acc_2 = 0;
for dataSetId = startIndex:endIndex   
    load(['E:\wangjing\4000��1000\Model1\' strcat('SNP_',num2str(dataSetId)) '.mat'])
    
    data=[double(pts),class'];
    data=double(data);
    factor=sort(factor);
    [Result_final,~,~]=epiACO3(data,AntNumber,IterationNumber,0.2);%MPMI
    Result=sort(Result_final,2);
%% TP
   count=Value_test(Result,factor);
   tp_all(dataSetId,1)=count(1,1);
   fn_all(dataSetId,1)=count(1,2);
   fp_all(dataSetId,1)=count(1,3);
   tn_all(dataSetId,1)=count(1,4);
           
%% power   
NumResult=size(Result,1);
Counter=zeros(endIndex-startIndex+1,3);
if NumResult==0
    Counter(dataSetId,1)=0;
    Counter(dataSetId,2)=0;
    Counter(dataSetId,3)=0;
end
    
if NumResult==1
    Counter(dataSetId,1)=isequal(factor,Result);
    Counter(dataSetId,2)=Counter(dataSetId,1);
    Counter(dataSetId,3)=1;
end

if NumResult>1
    Counter(dataSetId,1)=isequal(factor,Result(1,:));
    if Counter(dataSetId,1)==1
        Counter(dataSetId,2)=1;
    else
        for j=2:NumResult
            if isequal(factor,Result(j,:))==1
                Counter(dataSetId,2)=1;
            end
        end
    end
    Counter(dataSetId,3)=NumResult;
end
if Counter(dataSetId,1) == 1
    acc_1 = acc_1 + 1;
end
if Counter(dataSetId,2) == 1
    acc_2 = acc_2 + 1;
end
end
TP=sum(tp_all(:,1));
FN=sum(fn_all(:,1));
FP=sum(fp_all(:,1));
TN=sum(tn_all(:,1));
accuracy=(TP+TN)./(TP+FN+FP+TN);
precision=TP./(TP+FP);
recall=TP./(TP+FN);
F1=2.*TP./(2.*TP+FP+FN);

power1 = acc_1/endIndex;
power2 = acc_2/endIndex;

time=toc;
save('model1_MPMI_2000_100','accuracy','precision','recall','F1','power1','power2','time')

%% 
function count=Value_test(Result,factor)
count=zeros(1,4);
SNPnumber=100;
result=Result(1,:);
V = [result(:,1);result(:,2)];
V = unique(V);
for n = 1: size(V,1)
    if isequal(factor(1),V(n))|| isequal(factor(2),V(n))
        if isequal(factor(1),V(n))
            for l = 1: size(V,1)
                if isequal(factor(2),V(l))
                    count(1,1)=2;
                    count(1,2)=0;
                    break;
                else
                    count(1,1)=1;
                    count(1,2)=1;
                end
            end
        end
        if isequal(factor(2),V(n))
            for l = 1: size(V,1)
                if isequal(factor(1),V(l))
                   count(1,1)=2;
                   count(1,2)=0;
                    break;
                else
                    count(1,1)=1;
                   count(1,2)=1;
                end
            end
        end
    elseif count(1,1)==0
        count(1,1)=0;
       count(1,2)=2;
    end
end
number=length(V);
count(1,3)=number-count(1,1);
count(1,4)=SNPnumber-number-count(1,2);
end


